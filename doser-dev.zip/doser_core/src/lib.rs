pub mod error;
pub mod sampler;
use crate::error::{DoserError, Result};
use crate::sampler::{Sampler, now_ms};
use doser_traits::Motor;
use std::collections::VecDeque;

/// Status returned by Doser::step()
#[derive(Debug)]
pub enum DosingStatus {
    Running,
    Complete,
    Aborted(Box<DoserError>),
}

/// Doser struct for real-time, precise dosing control
pub struct Doser {
    sampler: Sampler,
    motor: Box<dyn Motor>,
    target_grams: f32,
    filter_window: VecDeque<f32>,
    filter_size: usize,
    last_weight: f32,
    dosing_started: bool,
    sample_timeout_ms: u64,
}

impl Doser {
    /// Create a new Doser
    pub fn new(
        sampler: Sampler,
        motor: Box<dyn Motor>,
        target_grams: f32,
        filter_size: usize,
        sample_timeout_ms: u64,
    ) -> Self {
        Doser {
            sampler,
            motor,
            target_grams,
            filter_window: VecDeque::with_capacity(filter_size),
            filter_size,
            last_weight: 0.0,
            dosing_started: false,
            sample_timeout_ms,
        }
    }

    /// Perform one step of dosing: read scale, update filter, control motor
    pub fn step(&mut self) -> Result<DosingStatus> {
        // 1. Read scale via sampler
        let now = now_ms();
        if self.sampler.stalled_for(now) > self.sample_timeout_ms {
            self.motor.stop();
            return Err(DoserError::Timeout("Scale sampling stalled".to_string()));
        }
        let weight = self.sampler.latest().unwrap_or(self.last_weight as i32) as f32;
        self.last_weight = weight;
        if weight < 0.0 {
            return Err(DoserError::Hardware(
                "Negative weight read from scale".to_string(),
            ));
        }
        // 2. Update moving average filter
        if self.filter_window.len() == self.filter_size {
            self.filter_window.pop_front();
        }
        self.filter_window.push_back(weight);
        let avg_weight = self.filter_window.iter().sum::<f32>() / self.filter_window.len() as f32;

        // 3. Control motor
        if avg_weight < self.target_grams {
            if !self.dosing_started {
                self.motor.start();
                self.dosing_started = true;
            }
            Ok(DosingStatus::Running)
        } else {
            if self.dosing_started {
                self.motor.stop();
                self.dosing_started = false;
            }
            Ok(DosingStatus::Complete)
        }
    }

    /// Get the last raw weight
    pub fn last_weight(&self) -> f32 {
        self.last_weight
    }

    /// Get the current filtered weight
    pub fn filtered_weight(&self) -> f32 {
        if self.filter_window.is_empty() {
            0.0
        } else {
            self.filter_window.iter().sum::<f32>() / self.filter_window.len() as f32
        }
    }
}

// Implement Debug for Doser

// Implement Debug for Doser
impl std::fmt::Debug for Doser {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Doser")
            .field("target_grams", &self.target_grams)
            .field("filter_size", &self.filter_size)
            .field("last_weight", &self.last_weight)
            .field("filtered_weight", &self.filtered_weight())
            .field("dosing_started", &self.dosing_started)
            .finish()
    }
}

// Implement Display for Doser
impl std::fmt::Display for Doser {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "Doser(target_grams: {:.2}, filter_size: {}, last_weight: {:.2}, filtered_weight: {:.2}, dosing_started: {})",
            self.target_grams,
            self.filter_size,
            self.last_weight,
            self.filtered_weight(),
            self.dosing_started
        )
    }
}
pub mod calibration;
pub mod config;
pub mod dosing_strategy;
pub mod logger;
/// Builder for a dosing session
#[derive(Debug, Default, Clone)]
pub struct DosingSessionBuilder {
    target_grams: Option<f32>,
    max_attempts: Option<usize>,
    dt_pin: Option<u8>,
    sck_pin: Option<u8>,
    step_pin: Option<u8>,
    dir_pin: Option<u8>,
}

impl DosingSessionBuilder {
    pub fn new() -> Self {
        Self::default()
    }
    pub fn target_grams(mut self, grams: f32) -> Self {
        self.target_grams = Some(grams);
        self
    }
    pub fn max_attempts(mut self, attempts: usize) -> Self {
        self.max_attempts = Some(attempts);
        self
    }
    pub fn dt_pin(mut self, pin: u8) -> Self {
        self.dt_pin = Some(pin);
        self
    }
    pub fn sck_pin(mut self, pin: u8) -> Self {
        self.sck_pin = Some(pin);
        self
    }
    pub fn step_pin(mut self, pin: u8) -> Self {
        self.step_pin = Some(pin);
        self
    }
    pub fn dir_pin(mut self, pin: u8) -> Self {
        self.dir_pin = Some(pin);
        self
    }
    pub fn build(self) -> Option<DosingSession> {
        Some(DosingSession {
            target_grams: self.target_grams?,
            max_attempts: self.max_attempts.unwrap_or(100),
            dt_pin: self.dt_pin?,
            sck_pin: self.sck_pin?,
            step_pin: self.step_pin?,
            dir_pin: self.dir_pin?,
        })
    }
}

/// ADT for a dosing session
#[derive(Debug, Clone)]
pub struct DosingSession {
    pub target_grams: f32,
    pub max_attempts: usize,
    pub dt_pin: u8,
    pub sck_pin: u8,
    pub step_pin: u8,
    pub dir_pin: u8,
}

impl std::fmt::Display for DosingSession {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "DosingSession(target_grams: {:.2}, max_attempts: {}, DT: {}, SCK: {}, STEP: {}, DIR: {})",
            self.target_grams,
            self.max_attempts,
            self.dt_pin,
            self.sck_pin,
            self.step_pin,
            self.dir_pin
        )
    }
}
impl DosingSession {
    /// Returns a dosing step iterator for the session
    pub fn steps<F>(&self, read_weight: F) -> DosingStepEnum<F>
    where
        F: FnMut() -> f32,
    {
        DosingStepEnum::Steps(DosingStep::new(
            self.target_grams,
            read_weight,
            self.max_attempts,
        ))
    }
}

/// ADT for dosing step iterator
pub enum DosingStepEnum<F>
where
    F: FnMut() -> f32,
{
    Steps(DosingStep<F>),
}

impl<F> Iterator for DosingStepEnum<F>
where
    F: FnMut() -> f32,
{
    type Item = (usize, f32);
    fn next(&mut self) -> Option<Self::Item> {
        match self {
            DosingStepEnum::Steps(iter) => iter.next(),
        }
    }
}
use std::fmt;
impl fmt::Display for DosingResult {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "Final weight: {:.2}g, Attempts: {}, Error: {}",
            self.final_weight,
            self.attempts,
            match &self.error {
                Some(e) => e.to_string(),
                None => "None".to_string(),
            }
        )
    }
}
/// Render a simple progress bar for dosing
pub fn render_progress_bar(current: f32, target: f32, bar_width: usize) -> String {
    let percent = (current / target * 100.0).min(100.0).max(0.0);
    let filled = ((percent / 100.0) * bar_width as f32).round() as usize;
    let empty = bar_width - filled;
    let bar = format!("[{}{}]", "#".repeat(filled), "-".repeat(empty));
    format!(
        "{} {:>5.1}% ({:.2}g / {:.2}g)",
        bar, percent, current, target
    )
}

/// Dosing result
#[derive(Debug, Clone)]
pub struct DosingResult {
    pub final_weight: f32,
    pub attempts: usize,
    pub error: Option<DoserError>,
}

impl Default for DosingResult {
    fn default() -> Self {
        DosingResult {
            final_weight: 0.0,
            attempts: 0,
            error: None,
        }
    }
}

/// Core dosing algorithm (hardware-agnostic)
/// Attempts to dose to the target weight.
///
/// # Errors
/// Returns `Err(DoserError)` if:
/// - `target_grams` is not positive
/// - `read_weight` closure returns a negative value
/// - Maximum attempts are exceeded before reaching target
///
/// # Returns
/// - Ok(DosingResult) if successful
/// - Err(DoserError) if a precondition or runtime error occurs
pub fn dose_to_target<F>(
    target_grams: f32,
    mut read_weight: F,
    max_attempts: usize,
) -> crate::error::Result<DosingResult>
where
    F: FnMut() -> f32,
{
    if target_grams <= 0.0 {
        return Err(crate::error::DoserError::Config(
            "Negative target grams".to_string(),
        ));
    }
    let mut attempts = 0;
    let mut current_weight = read_weight();
    while current_weight < target_grams {
        attempts += 1;
        if attempts > max_attempts {
            return Err(crate::error::DoserError::Config(
                "Max attempts exceeded".to_string(),
            ));
        }
        if current_weight < 0.0 {
            return Err(crate::error::DoserError::Hardware(
                "Negative weight reading".to_string(),
            ));
        }
        current_weight = read_weight();
    }
    Ok(DosingResult {
        final_weight: current_weight,
        attempts,
        error: None,
    })
}

/// Calibration math (returns scale factor)
pub fn calculate_scale_factor(known_weight: f32, raw: f32) -> f32 {
    if raw > 0.0 { known_weight / raw } else { 1.0 }
}

#[cfg(test)]
mod tests {
    use super::*;
    use rstest::rstest;

    #[rstest]
    #[case(10.0, 2.0, 5.0)]
    #[case(10.0, 0.0, 1.0)]
    #[case(0.0, 10.0, 0.0)]
    fn test_calculate_scale_factor(#[case] known: f32, #[case] raw: f32, #[case] expected: f32) {
        assert_eq!(calculate_scale_factor(known, raw), expected);
    }

    #[test]
    fn test_dose_to_target_success() {
        let mut w = 0.0;
        let result = dose_to_target(
            10.0,
            || {
                w += 2.0;
                w
            },
            10,
        );
        assert!(result.is_ok());
        let dosing = result.unwrap();
        assert_eq!(dosing.final_weight, 10.0);
        assert!(dosing.error.is_none());
    }

    #[test]
    fn test_dose_to_target_negative_target() {
        let result = dose_to_target(-5.0, || 0.0, 10);
        match result {
            Err(crate::error::DoserError::Config(msg)) => assert_eq!(msg, "Negative target grams"),
            _ => panic!("Expected Config error for negative target grams"),
        }
    }

    #[test]
    fn test_dose_to_target_max_attempts() {
        let mut w = 0.0;
        let result = dose_to_target(
            10.0,
            || {
                w += 1.0;
                w
            },
            5,
        );
        match result {
            Err(crate::error::DoserError::Config(msg)) => assert_eq!(msg, "Max attempts exceeded"),
            _ => panic!("Expected Config error for max attempts exceeded"),
        }
    }

    #[test]
    fn test_dose_to_target_negative_weight() {
        let mut w = 0.0;
        let result = dose_to_target(
            10.0,
            || {
                w -= 2.0;
                w
            },
            10,
        );
        match result {
            Err(crate::error::DoserError::Hardware(msg)) => {
                assert_eq!(msg, "Negative weight reading")
            }
            _ => panic!("Expected Hardware error for negative weight reading"),
        }
    }
}
/// Iterator over dosing steps, yielding (attempt, weight) each time.
pub struct DosingStep<F>
where
    F: FnMut() -> f32,
{
    target: f32,
    max_attempts: usize,
    read_weight: F,
    attempt: usize,
    finished: bool,
}

impl<F> DosingStep<F>
where
    F: FnMut() -> f32,
{
    pub fn new(target: f32, read_weight: F, max_attempts: usize) -> Self {
        DosingStep {
            target,
            max_attempts,
            read_weight,
            attempt: 0,
            finished: false,
        }
    }
}

impl<F> Iterator for DosingStep<F>
where
    F: FnMut() -> f32,
{
    type Item = (usize, f32);
    fn next(&mut self) -> Option<Self::Item> {
        if self.finished || self.attempt >= self.max_attempts {
            return None;
        }
        self.attempt += 1;
        let weight = (self.read_weight)();
        if weight >= self.target || weight < 0.0 {
            self.finished = true;
        }
        Some((self.attempt, weight))
    }
}

#[cfg(test)]
mod iterator_tests {
    use super::*;
    #[test]
    fn test_dosing_step_iterator() {
        let mut w = 0.0;
        let iter = DosingStep::new(
            6.0,
            || {
                w += 2.0;
                w
            },
            10,
        );
        let steps: Vec<_> = iter.collect();
        assert_eq!(steps, vec![(1, 2.0), (2, 4.0), (3, 6.0)]);
    }

    #[test]
    fn test_dosing_step_iterator_negative_weight() {
        let mut w = 2.0;
        let iter = DosingStep::new(
            6.0,
            || {
                w -= 3.0;
                w
            },
            10,
        );
        let steps: Vec<_> = iter.collect();
        // Should stop after first negative weight
        assert_eq!(steps, vec![(1, -1.0)]);
    }

    #[test]
    fn test_dosing_step_iterator_max_attempts() {
        let mut w = 0.0;
        let iter = DosingStep::new(
            100.0,
            || {
                w += 1.0;
                w
            },
            3,
        );
        let steps: Vec<_> = iter.collect();
        assert_eq!(steps, vec![(1, 1.0), (2, 2.0), (3, 3.0)]);
    }

    #[test]
    fn test_dosing_step_enum_iterator() {
        let mut w = 0.0;
        let mut iter = DosingStepEnum::Steps(DosingStep::new(
            5.0,
            || {
                w += 2.0;
                w
            },
            10,
        ));
        let mut results = vec![];
        while let Some((attempt, weight)) = iter.next() {
            results.push((attempt, weight));
        }
        assert_eq!(results, vec![(1, 2.0), (2, 4.0), (3, 6.0)]);
    }

    #[test]
    fn test_dosing_session_builder_and_steps() {
        let builder = DosingSessionBuilder::new()
            .target_grams(6.0)
            .max_attempts(5)
            .dt_pin(1)
            .sck_pin(2)
            .step_pin(3)
            .dir_pin(4);
        let session = builder.build().unwrap();
        let mut w = 0.0;
        let mut iter = session.steps(|| {
            w += 2.0;
            w
        });
        let mut results = vec![];
        while let Some((attempt, weight)) = iter.next() {
            results.push((attempt, weight));
        }
        assert_eq!(results, vec![(1, 2.0), (2, 4.0), (3, 6.0)]);
    }

    #[test]
    fn test_dosing_session_builder_missing_fields() {
        let builder = DosingSessionBuilder::new()
            .target_grams(6.0)
            .max_attempts(5)
            .dt_pin(1)
            .sck_pin(2)
            .step_pin(3);
        // Missing dir_pin
        assert!(builder.build().is_none());
    }
}
