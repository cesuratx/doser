# Code of Conduct

All participants are expected to uphold the standards of respectful, inclusive, and professional conduct. Please be kind and constructive in all interactions.

- Be respectful and considerate.
- No harassment, discrimination, or offensive language.
- Report issues to maintainers if you observe violations.

Violations may result in removal from the project.
